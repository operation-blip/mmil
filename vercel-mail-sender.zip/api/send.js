import nodemailer from 'nodemailer';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const {
    to,
    subject,
    html,
    senderName,
    secretKey,
    smtpHost,
    smtpPort,
    smtpUser,
    smtpPass
  } = req.body;

  // التحقق من كود الحماية في حال تم ضبطه في إعدادات Vercel
  if (process.env.APP_SECRET && secretKey !== process.env.APP_SECRET) {
    return res.status(401).json({ error: 'كود الحماية (Secret Key) غير صحيح!' });
  }

  const finalUser = smtpUser || process.env.SMTP_USER;
  const finalPass = smtpPass || process.env.SMTP_PASS;
  const finalHost = smtpHost || process.env.SMTP_HOST || 'smtp.gmail.com';
  const finalPort = Number(smtpPort || process.env.SMTP_PORT || 465);

  if (!finalUser || !finalPass) {
    return res.status(400).json({
      error: 'بيانات الإيميل غير مكتملة! أضف SMTP_USER و SMTP_PASS في Vercel أو أدخلها في إعدادات الواجهة.'
    });
  }

  if (!to || !subject || !html) {
    return res.status(400).json({ error: 'يرجى ملء جميع الحقول المطلوبة (المستلم، العنوان، المحتوى).' });
  }

  try {
    const transporter = nodemailer.createTransport({
      host: finalHost,
      port: finalPort,
      secure: finalPort === 465,
      auth: {
        user: finalUser,
        pass: finalPass,
      },
    });

    const fromAddress = senderName
      ? `"${senderName}" <${finalUser}>`
      : finalUser;

    await transporter.sendMail({
      from: fromAddress,
      to: to.trim(),
      subject: subject,
      html: html,
    });

    return res.status(200).json({ success: true, email: to });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
